import json
import boto3

ecs_client = boto3.client('ecs')

def lambda_handler(event, context):
    task_definition_name = event['taskDefinition']
    container_name = event['containerName']
    new_image = event['dataImage']
    
    # Describe the existing task definition
    response = ecs_client.describe_task_definition(taskDefinition=task_definition_name)
    task_def = response['taskDefinition']
    
    # Modify the container definition with the new image URL
    container_definitions = task_def['containerDefinitions']
    for container in container_definitions:
        if container['name'] == container_name:
            container['image'] = new_image
    
    # Register the new task definition with the updated container definition
    new_task_def_response = ecs_client.register_task_definition(
        family=task_def['family'],
        taskRoleArn=task_def['taskRoleArn'],
        executionRoleArn=task_def['executionRoleArn'],
        networkMode=task_def['networkMode'],
        containerDefinitions=container_definitions,
        volumes=task_def.get('volumes', []),
        placementConstraints=task_def.get('placementConstraints', []),
        requiresCompatibilities=task_def.get('requiresCompatibilities', []),
        cpu=task_def['cpu'],
        memory=task_def['memory']
    )
    
    new_task_def_arn = new_task_def_response['taskDefinition']['taskDefinitionArn']
    
    return {
        'statusCode': 200,
        'body': json.dumps(f'New task definition created: {new_task_def_arn}')    }
